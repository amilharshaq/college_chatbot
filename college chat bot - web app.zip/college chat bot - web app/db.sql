/*
SQLyog Community v13.1.6 (64 bit)
MySQL - 5.5.20-log : Database - college_chatbot
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`college_chatbot` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `college_chatbot`;

/*Table structure for table `assign` */

DROP TABLE IF EXISTS `assign`;

CREATE TABLE `assign` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `lid` int(11) DEFAULT NULL,
  `sid` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

/*Data for the table `assign` */

insert  into `assign`(`id`,`lid`,`sid`) values 
(8,7,3),
(9,7,4),
(10,7,8);

/*Table structure for table `attendence` */

DROP TABLE IF EXISTS `attendence`;

CREATE TABLE `attendence` (
  `attid` int(11) NOT NULL AUTO_INCREMENT,
  `stid` int(11) DEFAULT NULL,
  `sid` int(11) DEFAULT NULL,
  `status` int(50) DEFAULT NULL,
  `date` date DEFAULT NULL,
  PRIMARY KEY (`attid`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

/*Data for the table `attendence` */

insert  into `attendence`(`attid`,`stid`,`sid`,`status`,`date`) values 
(1,21,3,1,'2022-10-18'),
(2,21,3,0,'2022-10-13'),
(3,21,3,1,'2022-10-13'),
(4,21,3,1,'2022-10-27'),
(5,21,8,1,'2022-10-25');

/*Table structure for table `chatbot` */

DROP TABLE IF EXISTS `chatbot`;

CREATE TABLE `chatbot` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `lid` int(11) DEFAULT NULL,
  `question` varchar(100) DEFAULT NULL,
  `answer` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

/*Data for the table `chatbot` */

insert  into `chatbot`(`id`,`lid`,`question`,`answer`) values 
(1,20,'hi','hello'),
(2,20,'hello','haiii'),
(3,20,'aa',' Sorry, I can not understand the question'),
(4,20,'hello','haiii'),
(5,20,'what is this','a car'),
(6,20,'hoi\n\n',' Sorry, I can not understand the question'),
(7,20,'hiii',' Sorry, I can not understand the question'),
(8,21,'hello\n','haiii');

/*Table structure for table `club` */

DROP TABLE IF EXISTS `club`;

CREATE TABLE `club` (
  `clubid` int(11) NOT NULL AUTO_INCREMENT,
  `clubname` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`clubid`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

/*Data for the table `club` */

insert  into `club`(`clubid`,`clubname`) values 
(7,'w');

/*Table structure for table `complaint` */

DROP TABLE IF EXISTS `complaint`;

CREATE TABLE `complaint` (
  `coid` int(11) NOT NULL AUTO_INCREMENT,
  `lid` int(11) DEFAULT NULL,
  `complaint` varchar(50) DEFAULT NULL,
  `date` varchar(50) DEFAULT NULL,
  `reply` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`coid`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

/*Data for the table `complaint` */

insert  into `complaint`(`coid`,`lid`,`complaint`,`date`,`reply`) values 
(1,20,'dhh','2022-10-03','pending'),
(2,20,'hello','2022-10-12','pending'),
(3,20,'hello','2022-10-12','pending'),
(4,20,'ahah','2022-10-12','pending'),
(5,21,'hello','2022-10-12','ok'),
(6,21,'','2022-10-12','pending'),
(7,21,'bad','2022-10-12','pending');

/*Table structure for table `course` */

DROP TABLE IF EXISTS `course`;

CREATE TABLE `course` (
  `cid` int(11) NOT NULL AUTO_INCREMENT,
  `deptid` int(11) DEFAULT NULL,
  `coursename` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`cid`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

/*Data for the table `course` */

insert  into `course`(`cid`,`deptid`,`coursename`) values 
(1,1,'msc'),
(4,2,'eng');

/*Table structure for table `dataset` */

DROP TABLE IF EXISTS `dataset`;

CREATE TABLE `dataset` (
  `did` int(11) NOT NULL AUTO_INCREMENT,
  `questions` varchar(50) DEFAULT NULL,
  `answers` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`did`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

/*Data for the table `dataset` */

insert  into `dataset`(`did`,`questions`,`answers`) values 
(1,'hi','hello'),
(2,'hello','haiii'),
(3,'what is this','a car');

/*Table structure for table `department` */

DROP TABLE IF EXISTS `department`;

CREATE TABLE `department` (
  `deptid` int(11) NOT NULL AUTO_INCREMENT,
  `deptname` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`deptid`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

/*Data for the table `department` */

insert  into `department`(`deptid`,`deptname`) values 
(1,'cs'),
(2,'english');

/*Table structure for table `internalmark` */

DROP TABLE IF EXISTS `internalmark`;

CREATE TABLE `internalmark` (
  `inid` int(11) NOT NULL AUTO_INCREMENT,
  `sid` int(11) DEFAULT NULL,
  `stid` int(11) DEFAULT NULL,
  `mark` int(11) DEFAULT NULL,
  PRIMARY KEY (`inid`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

/*Data for the table `internalmark` */

insert  into `internalmark`(`inid`,`sid`,`stid`,`mark`) values 
(1,3,1,4),
(2,3,11,77);

/*Table structure for table `login` */

DROP TABLE IF EXISTS `login`;

CREATE TABLE `login` (
  `lid` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) DEFAULT NULL,
  `password` varchar(50) DEFAULT NULL,
  `type` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`lid`)
) ENGINE=MyISAM AUTO_INCREMENT=23 DEFAULT CHARSET=latin1;

/*Data for the table `login` */

insert  into `login`(`lid`,`username`,`password`,`type`) values 
(22,'admin','admin','admin'),
(7,'amil','amil','staff'),
(20,'st','st','student'),
(21,'amil1','Amil@123','student');

/*Table structure for table `notification` */

DROP TABLE IF EXISTS `notification`;

CREATE TABLE `notification` (
  `nid` int(11) NOT NULL AUTO_INCREMENT,
  `notification` varchar(50) DEFAULT NULL,
  `date` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`nid`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

/*Data for the table `notification` */

insert  into `notification`(`nid`,`notification`,`date`) values 
(4,'nat','2022-10-11');

/*Table structure for table `result` */

DROP TABLE IF EXISTS `result`;

CREATE TABLE `result` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sid` int(11) DEFAULT NULL,
  `result` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

/*Data for the table `result` */

insert  into `result`(`id`,`sid`,`result`) values 
(3,3,'pngegg.png'),
(4,3,'ORGANIC_FARMERS_APP.docx');

/*Table structure for table `staff` */

DROP TABLE IF EXISTS `staff`;

CREATE TABLE `staff` (
  `sid` int(11) NOT NULL AUTO_INCREMENT,
  `lid` int(11) DEFAULT NULL,
  `fname` varchar(50) DEFAULT NULL,
  `lname` varchar(50) DEFAULT NULL,
  `phone` bigint(50) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `qualification` varchar(50) DEFAULT NULL,
  `place` varchar(50) DEFAULT NULL,
  `post` varchar(50) DEFAULT NULL,
  `pin` bigint(50) DEFAULT NULL,
  PRIMARY KEY (`sid`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

/*Data for the table `staff` */

insert  into `staff`(`sid`,`lid`,`fname`,`lname`,`phone`,`email`,`qualification`,`place`,`post`,`pin`) values 
(5,7,'amil.','harshak.',9207684987,'amil@gmail.com.','bsc.','kkd.','kkd.',673308);

/*Table structure for table `student` */

DROP TABLE IF EXISTS `student`;

CREATE TABLE `student` (
  `stid` int(11) NOT NULL AUTO_INCREMENT,
  `lid` int(11) DEFAULT NULL,
  `cid` int(11) DEFAULT NULL,
  `stname` varchar(50) DEFAULT NULL,
  `qualification` varchar(50) DEFAULT NULL,
  `gender` varchar(50) DEFAULT NULL,
  `dob` date DEFAULT NULL,
  `phno` bigint(50) DEFAULT NULL,
  `semester` int(11) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `address` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`stid`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;

/*Data for the table `student` */

insert  into `student`(`stid`,`lid`,`cid`,`stname`,`qualification`,`gender`,`dob`,`phno`,`semester`,`email`,`address`) values 
(11,21,1,'amil','btech','male','2022-10-05',9632587412,1,'amil@gmail.com','kkd.');

/*Table structure for table `subject` */

DROP TABLE IF EXISTS `subject`;

CREATE TABLE `subject` (
  `subid` int(11) NOT NULL AUTO_INCREMENT,
  `cid` int(11) DEFAULT NULL,
  `subjectname` varchar(50) DEFAULT NULL,
  `semester` int(11) DEFAULT NULL,
  PRIMARY KEY (`subid`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

/*Data for the table `subject` */

insert  into `subject`(`subid`,`cid`,`subjectname`,`semester`) values 
(3,1,'r4r',1),
(4,4,'rrr',2),
(7,1,'hj',1),
(8,1,'coa',1);

/*Table structure for table `syllabus` */

DROP TABLE IF EXISTS `syllabus`;

CREATE TABLE `syllabus` (
  `syid` int(11) NOT NULL AUTO_INCREMENT,
  `cid` int(11) DEFAULT NULL,
  `syllabus` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`syid`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

/*Data for the table `syllabus` */

insert  into `syllabus`(`syid`,`cid`,`syllabus`) values 
(5,1,'pngegg.png');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
