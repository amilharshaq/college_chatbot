from flask import *

from src.chatbot import *
from src.dbconnectionnew import *

app = Flask(__name__)


@app.route('/login2',methods=['post'])
def login():
    print(request.form)
    uname = request.form['uname']
    pswd = request.form['pswd']

    qry = "select * from login where username=%s and password=%s and type='student'"
    val = (uname,pswd)
    res = selectone(qry,val)

    if res is None:
        return jsonify({"task":"failed"})
    else:
        return jsonify({"task":"valid","id":res['lid']})

@app.route('/view_complaint',methods=['post'])
def view_complaint():
    print(request.form)
    id = request.form['id']
    print(id)
    qry = "SELECT * FROM complaint WHERE lid=%s"
    val= (id)

    res = androidselectall(qry,val)

    print(res)

    return jsonify(res)

@app.route('/send_complaint',methods=['post'])
def send_complaint():
    print(request.form)
    id = request.form['id']
    complaint = request.form['complaint']
    qry = "insert into complaint values(null,%s,%s,curdate(),'pending')"
    val = (id,complaint)

    iud(qry,val)

    return jsonify({"task":"valid"})

@app.route('/view_syllabus',methods=['post'])
def view_syllabus():
    qry = "SELECT `course`.`coursename`,`syllabus`.* FROM `course` JOIN `syllabus` ON `course`.cid=`syllabus`.cid"
    res = androidselectallnew(qry)

    return jsonify(res)

@app.route('/view_notification',methods=['post'])
def view_notification():
    qry = "select * from notification"
    res = androidselectallnew(qry)
    return jsonify(res)



@app.route('/insertchatbot',methods=['post'])
def insertchatbot():
    qus = request.form['msg']
    print(qus)
    lid = request.form['lid']
    print(lid)

    res = cb(qus)
    qry = "INSERT INTO `chatbot` VALUES(NULL,%s,%s,%s)"
    val=(str(lid),qus,res)
    iud(qry,val)
    return jsonify({'task': "ok"})


@app.route('/response',methods=['post'])
def response():
    st_id = request.form['lid']

    qry = "SELECT question,lid,answer FROM `chatbot` WHERE `lid`=%s"
    val=(str(st_id))
    s = androidselectall(qry,val)


    # val=(st_id
    # s=select1(qry,val)
    row_headers = ['frmid', 'toid', 'msg']
    json_data = []
    for result in s:
        print(result)
        row = []
        row.append(st_id)
        row.append(0)
        row.append(result['question'])
        # row.append(result[3])
        json_data.append(dict(zip(row_headers, row)))
        row = []
        row.append(0)
        row.append(st_id)
        row.append(result['answer'])
        # row.append(result[3])
        json_data.append(dict(zip(row_headers, row)))
    print(json_data)
    return jsonify(json_data)


@app.route('/view_result',methods=['post'])
def view_result():
    print(request.form)
    id = request.form['id']
    qry = "SELECT `subject`.`subjectname`,`result`.* FROM `subject` JOIN `result` ON `subject`.subid=`result`.sid JOIN `course` ON `subject`.`cid`=`course`.`cid` JOIN `student` ON `course`.cid=`student`.cid where student.lid=%s"
    res = androidselectall(qry,id)
    print(res)
    return jsonify(res)



@app.route('/view_attendance',methods=['post'])
def view_attendance():

    id = request.form['id']

    qry = "SELECT `subject`.`subjectname`,COUNT(*) AS twh ,SUM(`status`) AS tph,(SUM(`status`)/COUNT(*))*100 AS per FROM `attendence` JOIN `subject` ON `subject`.`subid`=`attendence`.`sid` WHERE `attendence`.`stid`=%s GROUP BY `attendence`.`sid`"

    res = selectall2(qry,id)
    res1=[]
    for i in res:
        i['per']=str(i['per'])
        i['tph']=str(i['tph'])
        res1.append(i)
    print(res1)
    return jsonify(res1)



app.run(host='0.0.0.0',port=5000)